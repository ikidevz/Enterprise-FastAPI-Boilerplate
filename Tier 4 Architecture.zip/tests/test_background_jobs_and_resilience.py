import asyncio
import sys
import types

import pytest

from backend.common.background_jobs import BackgroundJobManager
from backend.common.exporters import export_metrics
from backend.observability.tracing import trace_span
from backend.resilience.retry import CircuitBreaker, CircuitBreakerOpenError, retry_async


def test_background_job_manager_runs_an_enqueued_job() -> None:
    """Ensures background job manager runs an enqueued job."""
    async def run_test() -> None:
        """Supports the test suite by run test."""
        manager = BackgroundJobManager()
        await manager.start()
        try:
            completed = {"value": False}

            def job() -> None:
                """Supports the test suite by job."""
                completed["value"] = True

            manager.enqueue(job)
            await asyncio.sleep(0.1)
            assert completed["value"] is True
        finally:
            await manager.stop()

    asyncio.run(run_test())


def test_background_job_manager_runs_an_async_job_too() -> None:
    """Ensures background job manager runs an async job too."""
    async def run_test() -> None:
        """Supports the test suite by run test."""
        manager = BackgroundJobManager()
        await manager.start()
        try:
            completed = {"value": False}

            async def async_job() -> None:
                """Supports the test suite by async job."""
                completed["value"] = True

            manager.enqueue(async_job)
            await asyncio.sleep(0.1)
            assert completed["value"] is True
        finally:
            await manager.stop()

    asyncio.run(run_test())


def test_retry_async_retries_on_failure_and_eventually_succeeds() -> None:
    """Ensures retry async retries on failure and eventually succeeds."""
    async def run_test() -> None:
        """Supports the test suite by run test."""
        attempts = {"count": 0}

        async def flaky() -> str:
            """Supports the test suite by flaky."""
            attempts["count"] += 1
            if attempts["count"] < 3:
                raise RuntimeError("temporary failure")
            return "ok"

        result = await retry_async(flaky, retries=3, delay=0.01)
        assert result == "ok"
        assert attempts["count"] == 3

    asyncio.run(run_test())


def test_retry_async_gives_up_after_exhausting_retries() -> None:
    """Ensures retry async gives up after exhausting retries."""
    async def run_test() -> None:
        """Supports the test suite by run test."""
        async def always_fails() -> str:
            """Supports the test suite by always fails."""
            raise RuntimeError("permanent failure")

        with pytest.raises(RuntimeError):
            await retry_async(always_fails, retries=2, delay=0.01)

    asyncio.run(run_test())


def test_circuit_breaker_opens_after_the_failure_threshold_and_blocks_further_calls() -> None:
    """Ensures circuit breaker opens after the failure threshold and blocks further calls."""
    breaker = CircuitBreaker(failure_threshold=2, reset_timeout=1.0)

    breaker.record_failure()
    breaker.record_failure()

    with pytest.raises(CircuitBreakerOpenError):
        breaker.before_call()


def test_circuit_breaker_stays_closed_below_the_failure_threshold() -> None:
    """Ensures circuit breaker stays closed below the failure threshold."""
    breaker = CircuitBreaker(failure_threshold=3, reset_timeout=1.0)

    breaker.record_failure()
    breaker.record_failure()

    breaker.before_call()


def test_trace_span_context_manager_does_not_raise() -> None:
    """trace_span should be safe to use even when tracing is a no-op (see section 2.3)."""
    with trace_span("test-span", component="tests"):
        pass


def test_export_metrics_does_not_raise_with_no_endpoint_configured() -> None:
    """With no EXPORTER_ENDPOINT set, export_metrics() should be a harmless no-op."""
    export_metrics()


def test_tracing_configuration_reads_environment_variables(monkeypatch: pytest.MonkeyPatch) -> None:
    """Ensures tracing configuration reads environment variables."""
    monkeypatch.setenv("ENABLE_TRACING", "true")
    monkeypatch.setenv("OTEL_MODE", "production")
    monkeypatch.setenv("OTEL_EXPORTER_OTLP_ENDPOINT", "http://collector:4318")

    from backend.observability.tracing import get_tracing_configuration

    try:
        config = get_tracing_configuration()

        assert config["enabled"] is True
        assert config["mode"] == "production"
        assert config["endpoint"] == "http://collector:4318"
    finally:
        monkeypatch.undo()


def test_tracing_uses_otlp_exporter_in_otlp_mode(monkeypatch: pytest.MonkeyPatch) -> None:
    """OTLP mode should instantiate the OTLP exporter when an endpoint is configured."""
    import backend.observability.tracing as tracing

    created: dict[str, object] = {}

    class FakeExporter:
        def __init__(self, endpoint: str) -> None:
            created["endpoint"] = endpoint

        def export(self, spans: object) -> None:
            return None

        def shutdown(self) -> None:
            return None

    fake_module = types.SimpleNamespace(OTLPSpanExporter=FakeExporter)
    monkeypatch.setitem(
        sys.modules, "opentelemetry.exporter.otlp.proto.http.trace_exporter", fake_module)
    monkeypatch.setenv("OTEL_MODE", "otlp")
    monkeypatch.setenv("OTEL_EXPORTER_OTLP_ENDPOINT", "http://collector:4318")
    monkeypatch.setattr(tracing, "_tracer", None)

    tracer = tracing._get_tracer()

    assert tracer is not None
    assert created.get("endpoint") == "http://collector:4318"
