from fastapi.testclient import TestClient

from conftest import auth_headers, login_user, register_user


def test_registration_creates_a_user_and_returns_its_public_profile(client: TestClient) -> None:
    """Ensures registration creates a user and returns its public profile."""
    user = register_user(
        client, email="new-user@example.com", username="new-user")

    assert user["email"] == "new-user@example.com"
    assert user["username"] == "new-user"
    assert "password" not in user
    assert "hashed_password" not in user


def test_weak_passwords_are_rejected_at_the_schema_level(client: TestClient) -> None:
    """Password strength validation happens in the Pydantic schema, before any DB work."""
    response = client.post(
        "/api/v1/users/",
        json={"email": "weak@example.com",
              "username": "weak", "password": "weakpass"},
    )

    assert response.status_code == 422


def test_duplicate_email_registration_is_rejected_cleanly(client: TestClient) -> None:
    """Ensures duplicate email registration is rejected cleanly."""
    payload = {
        "email": "duplicate@example.com",
        "username": "duplicate-one",
        "password": "StrongPass123!",
    }
    first = client.post("/api/v1/users/", json=payload)
    assert first.status_code == 201

    duplicate = client.post(
        "/api/v1/users/",
        json={**payload, "username": "duplicate-two"},
    )
    assert duplicate.status_code in (400, 409)
    assert duplicate.json()["error_code"] == "duplicate_user"


def test_duplicate_username_with_a_different_email_is_rejected_cleanly(client: TestClient) -> None:
    """Ensures duplicate username with a different email is rejected cleanly."""
    register_user(client, email="first-owner@example.com",
                  username="shared-name")

    response = client.post(
        "/api/v1/users/",
        json={
            "email": "second-owner@example.com",
            "username": "shared-name",
            "password": "StrongPass123!",
        },
    )

    assert response.status_code in (400, 409)


def test_login_with_correct_credentials_returns_tokens(client: TestClient) -> None:
    """Ensures login with correct credentials returns tokens."""
    register_user(client, email="login@example.com", username="login")

    response = client.post(
        "/api/v1/auth/login",
        data={"username": "login@example.com", "password": "StrongPass123!"},
    )

    assert response.status_code == 200
    body = response.json()
    assert body["token_type"] == "bearer"
    assert body["access_token"]
    assert body["refresh_token"]


def test_login_with_wrong_password_is_rejected(client: TestClient) -> None:
    """Ensures login with wrong password is rejected."""
    register_user(client, email="wrongpass@example.com", username="wrongpass")

    response = client.post(
        "/api/v1/auth/login",
        data={"username": "wrongpass@example.com", "password": "totally-wrong"},
    )

    assert response.status_code == 401


def test_login_with_unknown_email_is_rejected(client: TestClient) -> None:
    """Ensures login with unknown email is rejected."""
    response = client.post(
        "/api/v1/auth/login",
        data={"username": "nobody-registered@example.com", "password": "whatever"},
    )

    assert response.status_code == 401


def test_access_token_grants_access_to_the_current_user_profile(client: TestClient) -> None:
    """Ensures access token grants access to the current user profile."""
    register_user(client, email="me-route@example.com", username="me-route")
    token = login_user(client, email="me-route@example.com")

    response = client.get("/api/v1/auth/me", headers=auth_headers(token))

    assert response.status_code == 200
    assert response.json()["email"] == "me-route@example.com"


def test_access_token_for_deleted_user_is_rejected(client: TestClient) -> None:
    """Ensures access token for deleted user is rejected."""
    import asyncio

    from sqlalchemy import delete

    from backend.database import session as db_session
    from backend.domain.users.model import User

    register_user(client, email="deleted-user@example.com",
                  username="deleted-user")
    token = login_user(client, email="deleted-user@example.com")

    async def delete_user() -> None:
        """Supports the test suite by delete user."""
        async with db_session.SessionLocal() as db:
            await db.execute(delete(User).where(User.email == "deleted-user@example.com"))
            await db.commit()

    asyncio.run(delete_user())

    response = client.get("/api/v1/auth/me", headers=auth_headers(token))

    assert response.status_code == 401


def test_account_locks_after_five_failed_login_attempts(client: TestClient) -> None:
    """Ensures account locks after five failed login attempts."""
    register_user(client, email="lockout@example.com", username="lockout")

    for _ in range(5):
        response = client.post(
            "/api/v1/auth/login",
            data={"username": "lockout@example.com",
                  "password": "wrong-password"},
        )
        assert response.status_code == 401

    locked_response = client.post(
        "/api/v1/auth/login",
        data={"username": "lockout@example.com", "password": "StrongPass123!"},
    )
    assert locked_response.status_code == 401
    assert "incorrect email or password" in locked_response.json()[
        "detail"].lower()


def test_account_can_log_in_again_once_the_lockout_window_has_expired(client: TestClient) -> None:
    """Ensures account can log in again once the lockout window has expired."""
    import asyncio
    from datetime import datetime, timedelta, timezone

    from sqlalchemy import select

    from backend.database import session as db_session
    from backend.domain.users.model import User

    register_user(client, email="recovers@example.com", username="recovers")
    for _ in range(5):
        client.post(
            "/api/v1/auth/login",
            data={"username": "recovers@example.com",
                  "password": "wrong-password"},
        )

    async def expire_the_lockout_window() -> None:
        """Supports the test suite by expire the lockout window."""
        async with db_session.SessionLocal() as db:
            result = await db.execute(select(User).where(User.email == "recovers@example.com"))
            user = result.scalar_one()
            user.locked_until = datetime.now(
                timezone.utc) - timedelta(minutes=1)
            await db.commit()

    asyncio.run(expire_the_lockout_window())

    response = client.post(
        "/api/v1/auth/login",
        data={"username": "recovers@example.com",
              "password": "StrongPass123!"},
    )

    assert response.status_code == 200


def test_refresh_token_issues_a_new_access_and_refresh_token(client: TestClient) -> None:
    """Ensures refresh token issues a new access and refresh token."""
    register_user(client, email="refresh@example.com", username="refresh")
    login_response = client.post(
        "/api/v1/auth/login",
        data={"username": "refresh@example.com", "password": "StrongPass123!"},
    )
    refresh_token = login_response.json()["refresh_token"]

    response = client.post("/api/v1/auth/refresh",
                           json={"refresh_token": refresh_token})

    assert response.status_code == 200
    assert response.json()["token_type"] == "bearer"
    assert response.json()["access_token"]
    assert response.json()["refresh_token"]


def test_refresh_token_cannot_be_reused_after_rotation(client: TestClient) -> None:
    """Refresh tokens are single-use: once rotated, the old one must stop working."""
    register_user(client, email="rotate@example.com", username="rotate")
    login_response = client.post(
        "/api/v1/auth/login",
        data={"username": "rotate@example.com", "password": "StrongPass123!"},
    )
    old_refresh_token = login_response.json()["refresh_token"]

    first_use = client.post("/api/v1/auth/refresh",
                            json={"refresh_token": old_refresh_token})
    assert first_use.status_code == 200

    reuse_attempt = client.post(
        "/api/v1/auth/refresh", json={"refresh_token": old_refresh_token})
    assert reuse_attempt.status_code == 401


def test_replayed_refresh_token_revokes_all_current_sessions(client: TestClient) -> None:
    """A replayed refresh token should invalidate the user's other active sessions."""
    register_user(client, email="replay@example.com", username="replay")
    login_response = client.post(
        "/api/v1/auth/login",
        data={"username": "replay@example.com", "password": "StrongPass123!"},
    )
    old_refresh_token = login_response.json()["refresh_token"]
    original_access_token = login_response.json()["access_token"]

    first_refresh = client.post(
        "/api/v1/auth/refresh",
        json={"refresh_token": old_refresh_token},
    )
    assert first_refresh.status_code == 200

    replay_response = client.post(
        "/api/v1/auth/refresh",
        json={"refresh_token": old_refresh_token},
    )
    assert replay_response.status_code == 401

    protected_response = client.get(
        "/api/v1/auth/me",
        headers=auth_headers(original_access_token),
    )
    assert protected_response.status_code == 401


def test_user_registration_is_rate_limited_per_email(client: TestClient) -> None:
    """Repeated registration attempts for the same email should be throttled."""
    from backend.resilience.rate_limit import shared_rate_limiter

    shared_rate_limiter.reset()
    payload = {
        "email": "rate-limit@example.com",
        "username": "rate-limit",
        "password": "StrongPass123!",
    }

    for _ in range(5):
        response = client.post("/api/v1/users/", json=payload)
        assert response.status_code in (201, 400, 409)

    throttled = client.post("/api/v1/users/", json=payload)
    assert throttled.status_code == 429


def test_password_policy_endpoint_exposes_the_active_rules(client: TestClient) -> None:
    """The auth API should expose the password-policy settings for clients."""
    response = client.get("/api/v1/auth/password-policy")

    assert response.status_code == 200
    body = response.json()
    assert body["min_length"] >= 8
    assert body["require_uppercase"] is True


def test_refresh_with_an_unknown_token_is_rejected(client: TestClient) -> None:
    """Ensures refresh with an unknown token is rejected."""
    response = client.post("/api/v1/auth/refresh",
                           json={"refresh_token": "not-a-real-token"})

    assert response.status_code == 401


def test_logout_revokes_the_refresh_token(client: TestClient) -> None:
    """Ensures logout revokes the refresh token."""
    register_user(client, email="logout@example.com", username="logout")
    login_response = client.post(
        "/api/v1/auth/login",
        data={"username": "logout@example.com", "password": "StrongPass123!"},
    )
    refresh_token = login_response.json()["refresh_token"]
    access_token = login_response.json()["access_token"]

    logout_response = client.post(
        "/api/v1/auth/logout",
        headers={"Authorization": f"Bearer {access_token}"},
        json={"refresh_token": refresh_token})
    assert logout_response.status_code == 200

    reuse_attempt = client.post(
        "/api/v1/auth/refresh", json={"refresh_token": refresh_token})
    assert reuse_attempt.status_code == 401
