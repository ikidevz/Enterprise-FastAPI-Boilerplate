import redis.asyncio as redis

from backend.core.config import settings

redis_client = redis.from_url(settings.redis_url, decode_responses=True)
